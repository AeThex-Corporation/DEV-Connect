# Dev-Link - Roblox Developer Job Board

## Overview
Dev-Link is a job board platform for Roblox developers, featuring job listings, developer profiles, reputation systems, and team collaboration features.

## Project State
Fully functional with Supabase backend integration for database and authentication.

## Tech Stack
- **Frontend**: React 18 with Vite
- **Backend**: Supabase (PostgreSQL + Auth)
- **Styling**: Tailwind CSS with shadcn/ui components
- **Routing**: React Router DOM v7
- **State Management**: React Query (TanStack Query)
- **Icons**: Lucide React

## Running the App
Development server runs on port 5000:
```bash
npm run dev
```

## Project Structure
```
src/
├── api/                 # API client and entity definitions
│   └── base44Client.js  # Supabase adapter with CRUD operations
├── components/          # Reusable components
│   ├── ui/              # shadcn/ui components
│   └── utils/           # Utility functions
├── pages/               # Page components
│   └── Login.jsx        # Authentication page
├── hooks/               # Custom React hooks
├── lib/                 # Library utilities
└── utils/               # General utilities
supabase/
└── devlink_schema.sql   # Database schema with devlink_ prefixed tables
```

## Authentication
- Login page at `/Login` with Sign In/Sign Up tabs
- Uses Supabase Auth for email/password authentication
- Protected routes redirect to login automatically

## Database
- All tables use `devlink_` prefix in shared Supabase database
- Schema defined in `supabase/devlink_schema.sql` (34 tables total)
- Messages table uses `receiver_id` (not `recipient_id`)
- To run migrations: Copy SQL from schema file and execute in Supabase SQL Editor

### Core Tables
- devlink_profiles, devlink_jobs, devlink_applications, devlink_messages
- devlink_notifications, devlink_reviews, devlink_waitlist_signups

### Developer Features
- devlink_portfolios, devlink_work_experiences, devlink_endorsements
- devlink_skill_assessments, devlink_achievements, devlink_certifications
- devlink_saved_jobs, devlink_saved_developers, devlink_job_alerts

### Company/Team Features
- devlink_company_profiles, devlink_company_reviews, devlink_studios
- devlink_teams, devlink_groups, devlink_group_memberships

### Collaboration & Communication
- devlink_collab_rooms, devlink_collab_messages, devlink_collab_tasks
- devlink_chat_sessions, devlink_interview_proposals

### Gamification & Learning
- devlink_daily_challenges, devlink_learning_paths

### Marketplace & Payments
- devlink_assets, devlink_escrow_transactions, devlink_milestones

### Forum & Moderation
- devlink_forum_posts, devlink_forum_replies, devlink_moderation_actions

## Deployment
Configured for autoscale deployment:
- Build: `npm run build`
- Preview: `vite preview --host 0.0.0.0 --port 5000`

## AI Features
- OpenAI integration via Replit AI Integrations (no API key required)
- Environment variables: `VITE_AI_INTEGRATIONS_OPENAI_BASE_URL`, `VITE_AI_INTEGRATIONS_OPENAI_API_KEY`
- Features:
  - AI Job Recommendations based on developer profile
  - Profile Suggestions for optimizing developer profiles
  - Various AI assistants (career coach, skill analyzer, etc.)

## Roblox Integration
- Direct Roblox API integration for verification
- Functions: `verifyRobloxUsername`, `fetchRobloxUserGames`, `fetchRobloxGameStats`, `calculateRobloxReputation`
- Reputation system based on game visits, favorites, and game count

## Recent Changes (v0.1.5)
- Completed database schema with all 34 tables
- Added missing tables: assets, company_reviews, work_experiences, groups, group_memberships, interview_proposals, job_alerts, moderation_actions
- Added indexes for new tables

## Previous Changes (v0.1.4)
- Added OpenAI integration using Replit AI Integrations
- Implemented InvokeLLM with multiple calling conventions support
- Added GetJobRecommendations and GenerateProfileSuggestions helpers
- Fixed Roblox verification function calls throughout codebase
- Fixed profile creation flow with me() calls after auth

## Previous Changes (v0.1.3)
- Full Supabase integration for database and auth
- Created Login page with Sign In/Sign Up
- Added QueryClientProvider wrapper
- Fixed database column references (receiver_id)
- Configured deployment settings
