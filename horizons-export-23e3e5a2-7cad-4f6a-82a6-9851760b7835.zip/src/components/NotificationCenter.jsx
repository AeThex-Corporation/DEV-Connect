import React, { useState, useEffect } from 'react';
import { Bell, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { api } from '@/lib/db';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { Link } from 'react-router-dom';

const NotificationCenter = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!user) return;

    const loadNotifications = async () => {
      try {
        const data = await api.getNotifications(user.id);
        setNotifications(data || []);
        setUnreadCount(data ? data.filter(n => !n.is_read).length : 0);
      } catch (e) {
        console.error("Failed to load notifications", e);
      }
    };

    loadNotifications();

    // Realtime subscription for new notifications
    const channel = supabase
      .channel(`notifications:${user.id}`)
      .on('postgres_changes', { 
          event: 'INSERT', 
          schema: 'public', 
          table: 'notifications', 
          filter: `user_id=eq.${user.id}` 
      }, (payload) => {
          setNotifications(prev => [payload.new, ...prev]);
          setUnreadCount(prev => prev + 1);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const markAsRead = async (id) => {
    try {
      await api.markNotificationRead(id);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (e) {
      console.error("Failed to mark read", e);
    }
  };

  const markAllRead = async () => {
    const unread = notifications.filter(n => !n.is_read);
    if (unread.length === 0) return;
    
    try {
      await Promise.all(unread.map(n => api.markNotificationRead(n.id)));
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (e) {
        console.error("Failed to mark all read", e);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative text-gray-400 hover:text-white">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-black animate-pulse" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 bg-gray-900 border border-white/10 text-white" align="end">
        <div className="flex items-center justify-between p-4 border-b border-white/10 bg-black/20">
          <h4 className="font-semibold">Notifications</h4>
          {unreadCount > 0 && (
            <button onClick={markAllRead} className="text-xs text-blue-400 hover:text-blue-300">
              Mark all read
            </button>
          )}
        </div>
        <div className="max-h-[400px] overflow-y-auto">
          {notifications.length > 0 ? (
            notifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`p-4 border-b border-white/5 hover:bg-white/5 transition-colors relative group ${!notification.is_read ? 'bg-blue-500/5' : ''}`}
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-grow">
                     <h5 className="text-sm font-medium text-gray-200">{notification.title}</h5>
                     <p className="text-xs text-gray-400 mt-1 line-clamp-2">{notification.body}</p>
                     {notification.link && (
                        <Link 
                            to={notification.link} 
                            className="text-xs text-blue-400 hover:underline mt-2 inline-block"
                            onClick={() => { markAsRead(notification.id); setOpen(false); }}
                        >
                            View Details
                        </Link>
                     )}
                     <span className="text-[10px] text-gray-500 mt-2 block">{new Date(notification.created_at).toLocaleDateString()}</span>
                  </div>
                  {!notification.is_read && (
                     <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-6 w-6 text-gray-500 hover:text-green-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => markAsRead(notification.id)}
                        title="Mark as read"
                     >
                        <Check className="h-3 w-3" />
                     </Button>
                  )}
                </div>
              </div>
            ))
          ) : (
            <div className="p-8 text-center text-gray-500 text-sm">
              No notifications yet.
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default NotificationCenter;