import { base44 } from './base44Client';


export const Job = base44.entities.Job;

export const Application = base44.entities.Application;

export const Message = base44.entities.Message;

export const Notification = base44.entities.Notification;

export const Review = base44.entities.Review;

export const EscrowTransaction = base44.entities.EscrowTransaction;

export const Milestone = base44.entities.Milestone;

export const Portfolio = base44.entities.Portfolio;

export const Contract = base44.entities.Contract;

export const TimeEntry = base44.entities.TimeEntry;

export const Meeting = base44.entities.Meeting;

export const Invoice = base44.entities.Invoice;

export const Team = base44.entities.Team;

export const Report = base44.entities.Report;

export const SkillAssessment = base44.entities.SkillAssessment;

export const Achievement = base44.entities.Achievement;

export const SavedDeveloper = base44.entities.SavedDeveloper;

export const JobAlert = base44.entities.JobAlert;

export const Referral = base44.entities.Referral;

export const Analytics = base44.entities.Analytics;

export const Interview = base44.entities.Interview;

export const ChatSession = base44.entities.ChatSession;

export const Endorsement = base44.entities.Endorsement;

export const ForumPost = base44.entities.ForumPost;

export const ForumReply = base44.entities.ForumReply;

export const JobAnalytics = base44.entities.JobAnalytics;

export const CollabRoom = base44.entities.CollabRoom;

export const CollabMessage = base44.entities.CollabMessage;

export const ModerationAction = base44.entities.ModerationAction;

export const LearningPath = base44.entities.LearningPath;

export const PortfolioFeedback = base44.entities.PortfolioFeedback;

export const Asset = base44.entities.Asset;

export const AssetPurchase = base44.entities.AssetPurchase;

export const AssetReview = base44.entities.AssetReview;

export const MentorshipRequest = base44.entities.MentorshipRequest;

export const MentorshipSession = base44.entities.MentorshipSession;

export const CollabTask = base44.entities.CollabTask;

export const Certification = base44.entities.Certification;

export const Subscription = base44.entities.Subscription;

export const PlatformTransaction = base44.entities.PlatformTransaction;

export const FeaturedListing = base44.entities.FeaturedListing;

export const PremiumCourse = base44.entities.PremiumCourse;

export const CourseEnrollment = base44.entities.CourseEnrollment;

export const CompanyProfile = base44.entities.CompanyProfile;

export const CompanyReview = base44.entities.CompanyReview;

export const WaitlistSignup = base44.entities.WaitlistSignup;

export const WorkExperience = base44.entities.WorkExperience;

export const Group = base44.entities.Group;

export const GroupMembership = base44.entities.GroupMembership;

export const CommunityContribution = base44.entities.CommunityContribution;

export const CommunityBadge = base44.entities.CommunityBadge;

export const OfferLetter = base44.entities.OfferLetter;

export const InterviewProposal = base44.entities.InterviewProposal;

export const GroupChat = base44.entities.GroupChat;

export const LearningResource = base44.entities.LearningResource;

export const UserLearningProgress = base44.entities.UserLearningProgress;

export const ProfileOptimizationSuggestion = base44.entities.ProfileOptimizationSuggestion;

export const DailyChallenge = base44.entities.DailyChallenge;

export const SavedJob = base44.entities.SavedJob;

export const FeedChat = base44.entities.FeedChat;

export const Studio = base44.entities.Studio;



// auth sdk:
export const User = base44.auth;