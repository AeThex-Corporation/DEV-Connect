import { base44 } from './base44Client';


export const fetchRobloxJobs = base44.functions.fetchRobloxJobs;

export const fetchZipRecruiterJobs = base44.functions.fetchZipRecruiterJobs;

export const fetchRobloxGameStats = base44.functions.fetchRobloxGameStats;

export const fetchRobloxUserGames = base44.functions.fetchRobloxUserGames;

export const verifyRobloxUsername = base44.functions.verifyRobloxUsername;

export const fetchRobloxGroups = base44.functions.fetchRobloxGroups;

export const calculateRobloxReputation = base44.functions.calculateRobloxReputation;

export const fetchRobloxTalentHub = base44.functions.fetchRobloxTalentHub;

export const verifyRobloxWithOpenCloud = base44.functions.verifyRobloxWithOpenCloud;

export const fetchDevForumResources = base44.functions.fetchDevForumResources;

export const fetchDevForumUpdates = base44.functions.fetchDevForumUpdates;

export const verifyDevForum = base44.functions.verifyDevForum;

export const fetchGroupGames = base44.functions.fetchGroupGames;

