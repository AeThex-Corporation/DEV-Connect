import React from 'react';
    import { Link } from 'react-router-dom';

    const FooterLink = ({ to, children }) => (
      <Link to={to} className="text-gray-400 hover:text-white transition-colors duration-200">{children}</Link>
    );

    export const Footer = () => {
      return (
        <footer className="relative z-10 px-6 py-16 border-t border-gray-800 bg-black/10">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              <div className="md:col-span-1">
                <div className="flex items-center space-x-3 mb-4">
                  <img 
                    src="/logo.svg" 
                    alt="Dev-Connect Logo" 
                    className="w-8 h-8"
                  />
                  <span className="text-xl font-bold">Dev-Connect</span>
                </div>
                <p className="text-gray-400">The central hub for creators. A product within the <a href="https://aethex.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">AeThex</a> ecosystem.</p>
              </div>
              
              <div>
                <p className="font-semibold text-white mb-4">Platform</p>
                <div className="flex flex-col space-y-2">
                  <FooterLink to="/developers">Find Talent</FooterLink>
                  <FooterLink to="/jobs">Find Work</FooterLink>
                  <FooterLink to="/studios">Studios</FooterLink>
                  <FooterLink to="/team-ups">Team-Ups</FooterLink>
                </div>
              </div>

              <div>
                <p className="font-semibold text-white mb-4">Company</p>
                <div className="flex flex-col space-y-2">
                  <FooterLink to="/about">About Us</FooterLink>
                  <FooterLink to="/changelog">Changelog</FooterLink>
                  <FooterLink to="/terms-of-service">Terms of Service</FooterLink>
                  <FooterLink to="/privacy-policy">Privacy Policy</FooterLink>
                </div>
              </div>

              <div>
                <p className="font-semibold text-white mb-4">Safety & Resources</p>
                <div className="flex flex-col space-y-2">
                  <FooterLink to="/safety/verification">Verification</FooterLink>
                  <FooterLink to="/safety/moderation">Moderation</FooterLink>
                  <FooterLink to="/resources">Resources</FooterLink>
                  <FooterLink to="/safety">Safety Center</FooterLink>
                </div>
              </div>
            </div>
            <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-500">
              <p>© 2025 Dev-Connect. All rights reserved.</p>
            </div>
          </div>
        </footer>
      );
    };