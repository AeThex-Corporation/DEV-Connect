-- DevLink Database Schema for Shared Supabase Database
-- Roblox Developer Job Board Platform

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- PROFILES TABLE (User accounts)
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE,
  full_name TEXT,
  avatar_url TEXT,
  roblox_avatar_url TEXT,
  banner_url TEXT,
  bio TEXT,
  
  -- Developer info
  developer_roles TEXT[] DEFAULT '{}',
  skills TEXT[] DEFAULT '{}',
  experience_level TEXT,
  years_of_experience INTEGER DEFAULT 0,
  portfolio_links TEXT[] DEFAULT '{}',
  work_status TEXT DEFAULT 'available',
  payment_preferences JSONB DEFAULT '{}',
  hourly_rate DECIMAL(10,2),
  
  -- Roblox verification
  roblox_username TEXT,
  roblox_user_id TEXT,
  roblox_verified BOOLEAN DEFAULT FALSE,
  roblox_data JSONB DEFAULT '{}',
  roblox_reputation_score INTEGER DEFAULT 0,
  roblox_reputation_tier TEXT,
  use_roblox_display_name BOOLEAN DEFAULT FALSE,
  use_roblox_avatar BOOLEAN DEFAULT FALSE,
  
  -- Other verifications
  github_username TEXT,
  github_verified BOOLEAN DEFAULT FALSE,
  devforum_username TEXT,
  devforum_verified BOOLEAN DEFAULT FALSE,
  forum_reputation INTEGER DEFAULT 0,
  
  -- Gamification
  xp_points INTEGER DEFAULT 0,
  level INTEGER DEFAULT 1,
  community_points INTEGER DEFAULT 0,
  streak_days INTEGER DEFAULT 0,
  
  -- Company/Employer info
  user_type TEXT DEFAULT 'developer',
  company_name TEXT,
  company_id UUID,
  platform_roles TEXT[] DEFAULT '{}',
  
  -- Settings
  avatar_customization JSONB DEFAULT '{}',
  admin BOOLEAN DEFAULT FALSE,
  is_premium BOOLEAN DEFAULT FALSE,
  stripe_account_id TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- JOBS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT,
  
  -- Requirements
  required_roles TEXT[] DEFAULT '{}',
  required_skills TEXT[] DEFAULT '{}',
  experience_level TEXT,
  programming_languages TEXT[] DEFAULT '{}',
  frameworks TEXT[] DEFAULT '{}',
  
  -- Payment
  payment_type TEXT DEFAULT 'fixed',
  budget_range JSONB DEFAULT '{}',
  salary_min DECIMAL(10,2),
  salary_max DECIMAL(10,2),
  
  -- Job details
  timeline TEXT,
  remote_type TEXT DEFAULT 'remote',
  preferred_locations TEXT[] DEFAULT '{}',
  preferred_timezones TEXT[] DEFAULT '{}',
  company_size TEXT,
  
  -- Status
  status TEXT DEFAULT 'open',
  application_deadline TIMESTAMPTZ,
  application_count INTEGER DEFAULT 0,
  view_count INTEGER DEFAULT 0,
  
  -- Employer info
  employer_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  company_name TEXT,
  company_logo TEXT,
  
  -- External job metadata
  metadata JSONB DEFAULT '{}',
  
  created_date TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- APPLICATIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID REFERENCES devlink_jobs(id) ON DELETE CASCADE,
  applicant_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  
  cover_letter TEXT,
  proposed_rate TEXT,
  estimated_timeline TEXT,
  availability_start_date TIMESTAMPTZ,
  portfolio_links TEXT[] DEFAULT '{}',
  
  status TEXT DEFAULT 'pending',
  reviewed BOOLEAN DEFAULT FALSE,
  
  -- Review from employer
  review_text TEXT,
  rating INTEGER,
  categories JSONB DEFAULT '{}',
  would_work_again BOOLEAN,
  company_response TEXT,
  company_response_date TIMESTAMPTZ,
  
  created_date TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- WAITLIST SIGNUPS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_waitlist_signups (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  user_type TEXT DEFAULT 'developer',
  referral_source TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- MESSAGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  receiver_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  type TEXT DEFAULT 'info',
  title TEXT NOT NULL,
  message TEXT,
  link TEXT,
  metadata JSONB DEFAULT '{}',
  read BOOLEAN DEFAULT FALSE,
  created_date TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- REVIEWS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID REFERENCES devlink_jobs(id) ON DELETE SET NULL,
  reviewer_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  reviewee_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  review_text TEXT,
  review_type TEXT,
  categories JSONB DEFAULT '{}',
  would_work_again BOOLEAN,
  created_date TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- COMPANY PROFILES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_company_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  company_name TEXT NOT NULL,
  tagline TEXT,
  description TEXT,
  industry TEXT,
  company_size TEXT,
  founded_year INTEGER,
  location TEXT,
  website_url TEXT,
  logo_url TEXT,
  banner_url TEXT,
  brand_colors JSONB DEFAULT '{}',
  social_links JSONB DEFAULT '{}',
  culture_values TEXT[] DEFAULT '{}',
  perks_benefits TEXT[] DEFAULT '{}',
  tech_stack TEXT[] DEFAULT '{}',
  current_projects JSONB DEFAULT '[]',
  verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- STUDIOS TABLE (Roblox Groups)
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_studios (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_profile_id UUID REFERENCES devlink_company_profiles(id) ON DELETE CASCADE,
  studio_name TEXT,
  description TEXT,
  roblox_group_id TEXT,
  roblox_group_data JSONB DEFAULT '{}',
  user_role_in_group TEXT,
  user_rank_in_group INTEGER,
  verified BOOLEAN DEFAULT FALSE,
  status TEXT DEFAULT 'active',
  member_count INTEGER DEFAULT 0,
  banner_url TEXT,
  total_games INTEGER DEFAULT 0,
  total_visits BIGINT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SAVED JOBS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_saved_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  job_id UUID REFERENCES devlink_jobs(id) ON DELETE CASCADE,
  priority TEXT DEFAULT 'medium',
  notes TEXT,
  created_date TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, job_id)
);

-- ============================================
-- ENDORSEMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_endorsements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  endorsee_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  endorser_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  skill_name TEXT NOT NULL,
  relationship TEXT,
  endorsement_strength INTEGER DEFAULT 1,
  created_date TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SKILL ASSESSMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_skill_assessments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  skill_name TEXT NOT NULL,
  assessment_type TEXT,
  score INTEGER,
  questions_answered INTEGER DEFAULT 0,
  questions_correct INTEGER DEFAULT 0,
  time_taken_minutes INTEGER,
  time_limit_minutes INTEGER,
  passed BOOLEAN DEFAULT FALSE,
  passing_score INTEGER,
  anti_cheat_flags JSONB DEFAULT '[]',
  proctoring_enabled BOOLEAN DEFAULT FALSE,
  questions JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- CERTIFICATIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_certifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  skill_name TEXT NOT NULL,
  certification_level TEXT,
  score INTEGER,
  percentile INTEGER,
  certificate_url TEXT,
  verification_code TEXT UNIQUE,
  issued_date TIMESTAMPTZ DEFAULT NOW(),
  expiry_date TIMESTAMPTZ,
  status TEXT DEFAULT 'active',
  verified BOOLEAN DEFAULT FALSE
);

-- ============================================
-- ACHIEVEMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_achievements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  achievement_type TEXT NOT NULL,
  title TEXT,
  description TEXT,
  xp_earned INTEGER DEFAULT 0,
  badge_url TEXT,
  unlocked_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- DAILY CHALLENGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_daily_challenges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  date DATE DEFAULT CURRENT_DATE,
  challenge_type TEXT,
  title TEXT,
  description TEXT,
  xp_reward INTEGER DEFAULT 0,
  target_count INTEGER DEFAULT 1,
  current_progress INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  streak_bonus INTEGER DEFAULT 0,
  bonus_xp INTEGER DEFAULT 0,
  UNIQUE(user_id, date, challenge_type)
);

-- ============================================
-- LEARNING PATHS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_learning_paths (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  path_name TEXT NOT NULL,
  target_role TEXT,
  current_level TEXT,
  target_level TEXT,
  skill_gaps JSONB DEFAULT '[]',
  recommended_resources JSONB DEFAULT '[]',
  suggested_projects JSONB DEFAULT '[]',
  milestones JSONB DEFAULT '[]',
  estimated_duration_weeks INTEGER,
  progress_percentage INTEGER DEFAULT 0,
  ai_recommendations JSONB DEFAULT '{}',
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- COLLAB ROOMS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_collab_rooms (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_name TEXT NOT NULL,
  room_type TEXT DEFAULT 'general',
  creator_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  participant_ids UUID[] DEFAULT '{}',
  related_job_id UUID REFERENCES devlink_jobs(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'active',
  started_at TIMESTAMPTZ DEFAULT NOW(),
  code_snippets JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- COLLAB MESSAGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_collab_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_id UUID REFERENCES devlink_collab_rooms(id) ON DELETE CASCADE,
  sender_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  message_type TEXT DEFAULT 'text',
  content TEXT,
  file_url TEXT,
  attachments JSONB DEFAULT '[]',
  read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMPTZ,
  created_date TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- COLLAB TASKS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_collab_tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  room_id UUID REFERENCES devlink_collab_rooms(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  priority TEXT DEFAULT 'medium',
  due_date TIMESTAMPTZ,
  estimated_hours INTEGER,
  created_by UUID REFERENCES devlink_profiles(id) ON DELETE SET NULL,
  assigned_to UUID REFERENCES devlink_profiles(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'pending',
  blocked_by UUID[],
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- ESCROW TRANSACTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_escrow_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID REFERENCES devlink_jobs(id) ON DELETE SET NULL,
  developer_id UUID REFERENCES devlink_profiles(id) ON DELETE SET NULL,
  employer_id UUID REFERENCES devlink_profiles(id) ON DELETE SET NULL,
  total_amount DECIMAL(12,2),
  funded_amount DECIMAL(12,2) DEFAULT 0,
  released_amount DECIMAL(12,2) DEFAULT 0,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending',
  funded_date TIMESTAMPTZ,
  created_date TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- MILESTONES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_milestones (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID REFERENCES devlink_jobs(id) ON DELETE CASCADE,
  escrow_id UUID REFERENCES devlink_escrow_transactions(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  amount DECIMAL(10,2),
  status TEXT DEFAULT 'pending',
  submission_notes TEXT,
  submitted_date TIMESTAMPTZ,
  approved_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- FORUM POSTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_forum_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  author_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT,
  category TEXT,
  tags TEXT[] DEFAULT '{}',
  upvotes INTEGER DEFAULT 0,
  downvotes INTEGER DEFAULT 0,
  view_count INTEGER DEFAULT 0,
  reply_count INTEGER DEFAULT 0,
  pinned BOOLEAN DEFAULT FALSE,
  locked BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- FORUM REPLIES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_forum_replies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID REFERENCES devlink_forum_posts(id) ON DELETE CASCADE,
  author_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  upvotes INTEGER DEFAULT 0,
  downvotes INTEGER DEFAULT 0,
  is_solution BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- PORTFOLIOS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_portfolios (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  project_type TEXT,
  technologies TEXT[] DEFAULT '{}',
  images TEXT[] DEFAULT '{}',
  video_url TEXT,
  live_url TEXT,
  github_url TEXT,
  roblox_game_id TEXT,
  featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- TEAMS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_teams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  owner_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  member_ids UUID[] DEFAULT '{}',
  logo_url TEXT,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SAVED DEVELOPERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_saved_developers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  developer_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, developer_id)
);

-- ============================================
-- CHAT SESSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_chat_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  participant_1_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  participant_2_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  last_message TEXT,
  last_message_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- ASSETS TABLE (Roblox Assets Marketplace)
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  seller_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  asset_type TEXT,
  category TEXT,
  price DECIMAL(10,2),
  currency TEXT DEFAULT 'USD',
  preview_images TEXT[] DEFAULT '{}',
  demo_video_url TEXT,
  download_url TEXT,
  file_size_bytes BIGINT,
  tags TEXT[] DEFAULT '{}',
  status TEXT DEFAULT 'active',
  sales_count INTEGER DEFAULT 0,
  view_count INTEGER DEFAULT 0,
  rating_average DECIMAL(3,2) DEFAULT 0,
  rating_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- COMPANY REVIEWS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_company_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID REFERENCES devlink_company_profiles(id) ON DELETE CASCADE,
  reviewer_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  title TEXT,
  review_text TEXT,
  pros TEXT,
  cons TEXT,
  work_type TEXT,
  employment_status TEXT,
  would_recommend BOOLEAN,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- WORK EXPERIENCES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_work_experiences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  company_name TEXT,
  job_title TEXT NOT NULL,
  description TEXT,
  start_date DATE,
  end_date DATE,
  is_current BOOLEAN DEFAULT FALSE,
  skills_used TEXT[] DEFAULT '{}',
  roblox_game_links TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- GROUPS TABLE (Community Groups)
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_groups (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  category TEXT,
  owner_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  logo_url TEXT,
  banner_url TEXT,
  member_count INTEGER DEFAULT 0,
  is_private BOOLEAN DEFAULT FALSE,
  invite_only BOOLEAN DEFAULT FALSE,
  rules TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- GROUP MEMBERSHIPS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_group_memberships (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  group_id UUID REFERENCES devlink_groups(id) ON DELETE CASCADE,
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'member',
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(group_id, user_id)
);

-- ============================================
-- INTERVIEW PROPOSALS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_interview_proposals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  job_id UUID REFERENCES devlink_jobs(id) ON DELETE CASCADE,
  application_id UUID REFERENCES devlink_applications(id) ON DELETE CASCADE,
  proposer_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  candidate_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  proposed_times JSONB DEFAULT '[]',
  selected_time TIMESTAMPTZ,
  interview_type TEXT DEFAULT 'video',
  meeting_link TEXT,
  notes TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- JOB ALERTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_job_alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  keywords TEXT[] DEFAULT '{}',
  roles TEXT[] DEFAULT '{}',
  skills TEXT[] DEFAULT '{}',
  experience_levels TEXT[] DEFAULT '{}',
  payment_types TEXT[] DEFAULT '{}',
  min_salary DECIMAL(10,2),
  remote_only BOOLEAN DEFAULT FALSE,
  frequency TEXT DEFAULT 'daily',
  is_active BOOLEAN DEFAULT TRUE,
  last_sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- MODERATION ACTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS devlink_moderation_actions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  moderator_id UUID REFERENCES devlink_profiles(id) ON DELETE SET NULL,
  target_user_id UUID REFERENCES devlink_profiles(id) ON DELETE CASCADE,
  target_content_id UUID,
  target_content_type TEXT,
  action_type TEXT NOT NULL,
  reason TEXT,
  notes TEXT,
  duration_hours INTEGER,
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX IF NOT EXISTS idx_devlink_jobs_status ON devlink_jobs(status);
CREATE INDEX IF NOT EXISTS idx_devlink_jobs_employer ON devlink_jobs(employer_id);
CREATE INDEX IF NOT EXISTS idx_devlink_jobs_created ON devlink_jobs(created_date DESC);
CREATE INDEX IF NOT EXISTS idx_devlink_applications_job ON devlink_applications(job_id);
CREATE INDEX IF NOT EXISTS idx_devlink_applications_applicant ON devlink_applications(applicant_id);
CREATE INDEX IF NOT EXISTS idx_devlink_messages_receiver ON devlink_messages(receiver_id);
CREATE INDEX IF NOT EXISTS idx_devlink_notifications_user ON devlink_notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_devlink_profiles_roblox ON devlink_profiles(roblox_username);
CREATE INDEX IF NOT EXISTS idx_devlink_saved_jobs_user ON devlink_saved_jobs(user_id);
CREATE INDEX IF NOT EXISTS idx_devlink_endorsements_endorsee ON devlink_endorsements(endorsee_id);
CREATE INDEX IF NOT EXISTS idx_devlink_assets_seller ON devlink_assets(seller_id);
CREATE INDEX IF NOT EXISTS idx_devlink_work_experiences_user ON devlink_work_experiences(user_id);
CREATE INDEX IF NOT EXISTS idx_devlink_group_memberships_user ON devlink_group_memberships(user_id);
CREATE INDEX IF NOT EXISTS idx_devlink_job_alerts_user ON devlink_job_alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_devlink_moderation_actions_target ON devlink_moderation_actions(target_user_id);

-- ============================================
-- ROW LEVEL SECURITY (Optional - Enable as needed)
-- ============================================
-- Uncomment these if you want to enable RLS

-- ALTER TABLE devlink_profiles ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE devlink_jobs ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE devlink_applications ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE devlink_messages ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE devlink_notifications ENABLE ROW LEVEL SECURITY;

-- Basic RLS policies (customize as needed)
-- CREATE POLICY "Public read access" ON devlink_profiles FOR SELECT USING (true);
-- CREATE POLICY "Users can update own profile" ON devlink_profiles FOR UPDATE USING (auth.uid()::text = id::text);
