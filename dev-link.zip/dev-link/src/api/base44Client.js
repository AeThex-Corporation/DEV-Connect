import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const supabase = supabaseUrl && supabaseAnonKey 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

const tableMap = {
  'User': 'devlink_profiles',
  'Job': 'devlink_jobs',
  'Application': 'devlink_applications',
  'Message': 'devlink_messages',
  'Notification': 'devlink_notifications',
  'Review': 'devlink_reviews',
  'WaitlistSignup': 'devlink_waitlist_signups',
  'Portfolio': 'devlink_portfolios',
  'Team': 'devlink_teams',
  'ForumPost': 'devlink_forum_posts',
  'ForumReply': 'devlink_forum_replies',
  'Asset': 'devlink_assets',
  'CompanyProfile': 'devlink_company_profiles',
  'CompanyReview': 'devlink_company_reviews',
  'WorkExperience': 'devlink_work_experiences',
  'Group': 'devlink_groups',
  'GroupMembership': 'devlink_group_memberships',
  'SavedJob': 'devlink_saved_jobs',
  'Endorsement': 'devlink_endorsements',
  'SkillAssessment': 'devlink_skill_assessments',
  'Achievement': 'devlink_achievements',
  'Certification': 'devlink_certifications',
  'Studio': 'devlink_studios',
  'EscrowTransaction': 'devlink_escrow_transactions',
  'Milestone': 'devlink_milestones',
  'CollabRoom': 'devlink_collab_rooms',
  'CollabMessage': 'devlink_collab_messages',
  'CollabTask': 'devlink_collab_tasks',
  'LearningPath': 'devlink_learning_paths',
  'DailyChallenge': 'devlink_daily_challenges',
  'SavedDeveloper': 'devlink_saved_developers',
  'ChatSession': 'devlink_chat_sessions',
  'InterviewProposal': 'devlink_interview_proposals',
  'JobAlert': 'devlink_job_alerts',
  'ModerationAction': 'devlink_moderation_actions',
};

const timestampColumnMap = {
  'Job': 'created_date',
  'Application': 'created_date',
  'Notification': 'created_date',
  'Review': 'created_date',
  'SavedJob': 'created_date',
  'Endorsement': 'created_date',
  'EscrowTransaction': 'created_date',
  'CollabMessage': 'created_date',
};

const createSupabaseEntity = (entityName) => {
  const tableName = tableMap[entityName] || 'devlink_' + entityName.toLowerCase() + 's';
  const timestampColumn = timestampColumnMap[entityName] || 'created_at';
  
  return {
    filter: async (query = {}, orderBy = null, options = {}) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.filter called with:`, query);
        return [];
      }
      try {
        let queryBuilder = supabase.from(tableName).select('*');
        
        Object.entries(query).forEach(([key, value]) => {
          if (key === '$or' && Array.isArray(value)) {
            const orConditions = value.map(condition => {
              return Object.entries(condition).map(([field, val]) => {
                if (typeof val === 'string' && val.includes('%')) {
                  return `${field}.ilike.${val}`;
                }
                return `${field}.eq.${val}`;
              }).join(',');
            }).join(',');
            if (orConditions) {
              queryBuilder = queryBuilder.or(orConditions);
            }
            return;
          }
          if (key === '$ilike') {
            Object.entries(value).forEach(([field, pattern]) => {
              queryBuilder = queryBuilder.ilike(field, pattern);
            });
          } else if (key === '$in') {
            Object.entries(value).forEach(([field, values]) => {
              queryBuilder = queryBuilder.in(field, values);
            });
          } else if (key === '$gte') {
            Object.entries(value).forEach(([field, val]) => {
              queryBuilder = queryBuilder.gte(field, val);
            });
          } else if (key === '$lte') {
            Object.entries(value).forEach(([field, val]) => {
              queryBuilder = queryBuilder.lte(field, val);
            });
          } else if (key === '$neq') {
            Object.entries(value).forEach(([field, val]) => {
              queryBuilder = queryBuilder.neq(field, val);
            });
          } else if (key === '$contains') {
            Object.entries(value).forEach(([field, val]) => {
              queryBuilder = queryBuilder.contains(field, val);
            });
          } else if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
            if (value.gte !== undefined) queryBuilder = queryBuilder.gte(key, value.gte);
            if (value.lte !== undefined) queryBuilder = queryBuilder.lte(key, value.lte);
            if (value.gt !== undefined) queryBuilder = queryBuilder.gt(key, value.gt);
            if (value.lt !== undefined) queryBuilder = queryBuilder.lt(key, value.lt);
            if (value.neq !== undefined) queryBuilder = queryBuilder.neq(key, value.neq);
            if (value.ilike !== undefined) queryBuilder = queryBuilder.ilike(key, value.ilike);
          } else {
            queryBuilder = queryBuilder.eq(key, value);
          }
        });
        
        const order = orderBy || timestampColumn;
        const ascending = options.ascending !== undefined ? options.ascending : false;
        queryBuilder = queryBuilder.order(order, { ascending });
        
        if (options.limit) {
          queryBuilder = queryBuilder.limit(options.limit);
        }
        
        if (options.offset) {
          queryBuilder = queryBuilder.range(options.offset, options.offset + (options.limit || 10) - 1);
        }
        
        const { data, error } = await queryBuilder;
        if (error) {
          console.error(`Error filtering ${entityName}:`, error);
          return [];
        }
        return data || [];
      } catch (error) {
        console.error(`Error in ${entityName}.filter:`, error);
        return [];
      }
    },
    
    find: async (id) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.find called with id:`, id);
        return null;
      }
      try {
        const { data, error } = await supabase
          .from(tableName)
          .select('*')
          .eq('id', id)
          .single();
        if (error) {
          console.error(`Error finding ${entityName}:`, error);
          return null;
        }
        return data;
      } catch (error) {
        console.error(`Error in ${entityName}.find:`, error);
        return null;
      }
    },
    
    create: async (data) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.create called with:`, data);
        return { id: Date.now().toString(), ...data, created_at: new Date().toISOString() };
      }
      try {
        const { data: result, error } = await supabase
          .from(tableName)
          .insert(data)
          .select()
          .single();
        if (error) {
          console.error(`Error creating ${entityName}:`, error);
          throw error;
        }
        return result;
      } catch (error) {
        console.error(`Error in ${entityName}.create:`, error);
        throw error;
      }
    },
    
    update: async (id, data) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.update called with:`, id, data);
        return { id, ...data };
      }
      try {
        const { data: result, error } = await supabase
          .from(tableName)
          .update(data)
          .eq('id', id)
          .select()
          .single();
        if (error) {
          console.error(`Error updating ${entityName}:`, error);
          throw error;
        }
        return result;
      } catch (error) {
        console.error(`Error in ${entityName}.update:`, error);
        throw error;
      }
    },
    
    upsert: async (data, conflictColumns = ['id']) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.upsert called with:`, data);
        return { id: Date.now().toString(), ...data };
      }
      try {
        const { data: result, error } = await supabase
          .from(tableName)
          .upsert(data, { onConflict: conflictColumns.join(',') })
          .select()
          .single();
        if (error) {
          console.error(`Error upserting ${entityName}:`, error);
          throw error;
        }
        return result;
      } catch (error) {
        console.error(`Error in ${entityName}.upsert:`, error);
        throw error;
      }
    },
    
    delete: async (id) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.delete called with id:`, id);
        return true;
      }
      try {
        const { error } = await supabase
          .from(tableName)
          .delete()
          .eq('id', id);
        if (error) {
          console.error(`Error deleting ${entityName}:`, error);
          return false;
        }
        return true;
      } catch (error) {
        console.error(`Error in ${entityName}.delete:`, error);
        return false;
      }
    },
    
    list: async (options = {}) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.list called`);
        return [];
      }
      try {
        let queryBuilder = supabase.from(tableName).select('*');
        
        const order = options.orderBy || timestampColumn;
        const ascending = options.ascending !== undefined ? options.ascending : false;
        queryBuilder = queryBuilder.order(order, { ascending });
        
        if (options.limit) {
          queryBuilder = queryBuilder.limit(options.limit);
        }
        
        const { data, error } = await queryBuilder;
        if (error) {
          console.error(`Error listing ${entityName}:`, error);
          return [];
        }
        return data || [];
      } catch (error) {
        console.error(`Error in ${entityName}.list:`, error);
        return [];
      }
    },
    
    count: async (query = {}) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.count called`);
        return 0;
      }
      try {
        let queryBuilder = supabase.from(tableName).select('*', { count: 'exact', head: true });
        Object.entries(query).forEach(([key, value]) => {
          if (!key.startsWith('$')) {
            queryBuilder = queryBuilder.eq(key, value);
          }
        });
        const { count, error } = await queryBuilder;
        if (error) {
          console.error(`Error counting ${entityName}:`, error);
          return 0;
        }
        return count || 0;
      } catch (error) {
        console.error(`Error in ${entityName}.count:`, error);
        return 0;
      }
    },
    
    search: async (searchTerm, searchFields = ['title', 'description'], options = {}) => {
      if (!supabase) {
        console.log(`[Mock] ${entityName}.search called`);
        return [];
      }
      try {
        let queryBuilder = supabase.from(tableName).select('*');
        
        const orConditions = searchFields.map(field => `${field}.ilike.%${searchTerm}%`).join(',');
        queryBuilder = queryBuilder.or(orConditions);
        
        const order = options.orderBy || timestampColumn;
        queryBuilder = queryBuilder.order(order, { ascending: false });
        
        if (options.limit) {
          queryBuilder = queryBuilder.limit(options.limit);
        }
        
        const { data, error } = await queryBuilder;
        if (error) {
          console.error(`Error searching ${entityName}:`, error);
          return [];
        }
        return data || [];
      } catch (error) {
        console.error(`Error in ${entityName}.search:`, error);
        return [];
      }
    }
  };
};

const entityNames = [
  'User', 'Job', 'Application', 'Message', 'Notification', 'Review',
  'EscrowTransaction', 'Milestone', 'Portfolio', 'Contract', 'TimeEntry',
  'Meeting', 'Invoice', 'Team', 'Report', 'SkillAssessment', 'Achievement',
  'SavedDeveloper', 'JobAlert', 'Referral', 'Analytics', 'Interview',
  'ChatSession', 'Endorsement', 'ForumPost', 'ForumReply', 'JobAnalytics',
  'CollabRoom', 'CollabMessage', 'ModerationAction', 'LearningPath',
  'PortfolioFeedback', 'Asset', 'AssetPurchase', 'AssetReview',
  'MentorshipRequest', 'MentorshipSession', 'CollabTask', 'Certification',
  'Subscription', 'PlatformTransaction', 'FeaturedListing', 'PremiumCourse',
  'CourseEnrollment', 'CompanyProfile', 'CompanyReview', 'WaitlistSignup',
  'WorkExperience', 'Group', 'GroupMembership', 'CommunityContribution',
  'CommunityBadge', 'OfferLetter', 'InterviewProposal', 'GroupChat',
  'LearningResource', 'UserLearningProgress', 'ProfileOptimizationSuggestion',
  'DailyChallenge', 'SavedJob', 'FeedChat', 'Studio'
];

const robloxFunctions = {
  verifyRobloxUsername: async (username) => {
    try {
      const response = await fetch(`https://users.roblox.com/v1/users/search?keyword=${encodeURIComponent(username)}&limit=10`);
      if (!response.ok) throw new Error('Roblox API error');
      const data = await response.json();
      const user = data.data?.find(u => u.name.toLowerCase() === username.toLowerCase());
      if (user) {
        return { success: true, userId: user.id, username: user.name, displayName: user.displayName };
      }
      return { success: false, message: 'User not found' };
    } catch (error) {
      console.error('Error verifying Roblox username:', error);
      return { success: false, message: error.message };
    }
  },
  
  fetchRobloxUserGames: async (userId) => {
    try {
      const response = await fetch(`https://games.roblox.com/v2/users/${userId}/games?accessFilter=Public&limit=50&sortOrder=Desc`);
      if (!response.ok) throw new Error('Roblox API error');
      const data = await response.json();
      return { success: true, games: data.data || [] };
    } catch (error) {
      console.error('Error fetching Roblox games:', error);
      return { success: false, games: [], message: error.message };
    }
  },
  
  fetchRobloxGameStats: async (universeId) => {
    try {
      const response = await fetch(`https://games.roblox.com/v1/games?universeIds=${universeId}`);
      if (!response.ok) throw new Error('Roblox API error');
      const data = await response.json();
      return { success: true, stats: data.data?.[0] || null };
    } catch (error) {
      console.error('Error fetching game stats:', error);
      return { success: false, stats: null, message: error.message };
    }
  },
  
  fetchRobloxGroups: async (userId) => {
    try {
      const response = await fetch(`https://groups.roblox.com/v1/users/${userId}/groups/roles`);
      if (!response.ok) throw new Error('Roblox API error');
      const data = await response.json();
      return { success: true, groups: data.data || [] };
    } catch (error) {
      console.error('Error fetching Roblox groups:', error);
      return { success: false, groups: [], message: error.message };
    }
  },
  
  calculateRobloxReputation: async (userId) => {
    try {
      const gamesResult = await robloxFunctions.fetchRobloxUserGames(userId);
      if (!gamesResult.success) return { score: 0, tier: 'Bronze', stats: {} };
      
      let totalVisits = 0;
      let totalFavorites = 0;
      let gameCount = gamesResult.games.length;
      
      for (const game of gamesResult.games.slice(0, 10)) {
        const statsResult = await robloxFunctions.fetchRobloxGameStats(game.id);
        if (statsResult.success && statsResult.stats) {
          totalVisits += statsResult.stats.visits || 0;
          totalFavorites += statsResult.stats.favoritedCount || 0;
        }
      }
      
      let score = 0;
      score += Math.min(totalVisits / 10000, 300);
      score += Math.min(totalFavorites / 100, 200);
      score += Math.min(gameCount * 20, 100);
      
      let tier = 'Bronze';
      if (score >= 800) tier = 'Legend';
      else if (score >= 650) tier = 'Diamond';
      else if (score >= 500) tier = 'Platinum';
      else if (score >= 350) tier = 'Gold';
      else if (score >= 200) tier = 'Silver';
      
      return {
        score: Math.round(score),
        tier,
        stats: {
          total_visits: totalVisits,
          total_favorites: totalFavorites,
          game_count: gameCount
        }
      };
    } catch (error) {
      console.error('Error calculating reputation:', error);
      return { score: 0, tier: 'Bronze', stats: {} };
    }
  },
  
  fetchGroupGames: async (groupId) => {
    try {
      const response = await fetch(`https://games.roblox.com/v2/groups/${groupId}/games?accessFilter=Public&limit=50&sortOrder=Desc`);
      if (!response.ok) throw new Error('Roblox API error');
      const data = await response.json();
      return { success: true, games: data.data || [] };
    } catch (error) {
      console.error('Error fetching group games:', error);
      return { success: false, games: [], message: error.message };
    }
  }
};

const mockFunction = async (...args) => {
  console.log('[Mock] Function called with:', args);
  return { success: true, data: null, message: 'Mock response - implement with real API' };
};

const functions = {
  verifyRobloxUsername: robloxFunctions.verifyRobloxUsername,
  fetchRobloxUserGames: robloxFunctions.fetchRobloxUserGames,
  fetchRobloxGameStats: robloxFunctions.fetchRobloxGameStats,
  fetchRobloxGroups: robloxFunctions.fetchRobloxGroups,
  calculateRobloxReputation: robloxFunctions.calculateRobloxReputation,
  fetchGroupGames: robloxFunctions.fetchGroupGames,
  
  fetchRobloxJobs: mockFunction,
  fetchZipRecruiterJobs: mockFunction,
  fetchRobloxTalentHub: mockFunction,
  verifyRobloxWithOpenCloud: mockFunction,
  fetchDevForumResources: mockFunction,
  fetchDevForumUpdates: mockFunction,
  verifyDevForum: mockFunction,
};

const entities = {};
entityNames.forEach(name => {
  entities[name] = createSupabaseEntity(name);
});

const authModule = {
  isAuthenticated: async () => {
    if (!supabase) return false;
    const { data: { session } } = await supabase.auth.getSession();
    return !!session;
  },
  
  me: async () => {
    if (!supabase) throw new Error('Not authenticated');
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) throw new Error('Not authenticated');
    
    let { data: profile, error: profileError } = await supabase
      .from('devlink_profiles')
      .select('*')
      .eq('id', user.id)
      .single();
    
    if (profileError && profileError.code === 'PGRST116') {
      const { data: newProfile, error: createError } = await supabase
        .from('devlink_profiles')
        .insert({
          id: user.id,
          email: user.email,
          full_name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'User',
          user_type: 'developer',
          developer_roles: [],
          skills: [],
          work_status: 'available'
        })
        .select()
        .single();
      
      if (createError) {
        console.error('Error creating profile:', createError);
        return { ...user, id: user.id, email: user.email };
      }
      profile = newProfile;
    }
    
    if (profile) {
      return { ...user, ...profile };
    }
    return { ...user, id: user.id, email: user.email };
  },
  
  logout: async () => {
    if (!supabase) return true;
    await supabase.auth.signOut();
    return true;
  },
  
  login: async (email, password) => {
    if (!supabase) {
      window.location.href = '/home';
      return;
    }
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  },
  
  signUp: async (email, password, metadata = {}) => {
    if (!supabase) {
      window.location.href = '/home';
      return;
    }
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: metadata }
    });
    if (error) throw error;
    return data;
  },
  
  redirectToLogin: (returnPath) => {
    console.log('Redirecting to login, return path:', returnPath);
    const encodedPath = encodeURIComponent(returnPath || '/Dashboard');
    window.location.href = `/Login?return=${encodedPath}`;
  },
  
  filter: async (query) => entities.User.filter(query),
  find: async (id) => entities.User.find(id),
  list: async () => entities.User.list(),
  update: async (id, data) => entities.User.update(id, data),
};

const getOpenAIClient = () => {
  const baseURL = import.meta.env.VITE_AI_INTEGRATIONS_OPENAI_BASE_URL;
  const apiKey = import.meta.env.VITE_AI_INTEGRATIONS_OPENAI_API_KEY;
  
  if (!baseURL || !apiKey) {
    return null;
  }
  
  return new OpenAI({
    baseURL,
    apiKey,
    dangerouslyAllowBrowser: true
  });
};

const integrations = {
  Core: {
    InvokeLLM: async (promptOrConfig, options = {}) => {
      try {
        const openai = getOpenAIClient();
        if (!openai) {
          console.log('[Integration] OpenAI not configured - AI features disabled');
          return { 
            success: false, 
            message: 'AI features are not configured. Please set up OpenAI integration.',
            response: null 
          };
        }
        
        let promptText;
        let configMessages;
        let config = options;
        
        if (typeof promptOrConfig === 'object' && promptOrConfig !== null && !Array.isArray(promptOrConfig)) {
          promptText = promptOrConfig.prompt;
          configMessages = promptOrConfig.messages;
          config = { ...promptOrConfig, ...options };
        } else {
          promptText = promptOrConfig;
        }
        
        const model = config.model || 'gpt-4o-mini';
        const systemPrompt = config.systemPrompt || config.system_prompt || 'You are a helpful assistant for a Roblox developer job board platform.';
        const wantsJson = config.json || config.response_json_schema;
        
        let messages;
        if (configMessages && Array.isArray(configMessages)) {
          messages = [...configMessages];
        } else {
          messages = [
            { role: 'system', content: systemPrompt }
          ];
          
          if (typeof promptText === 'string') {
            messages.push({ role: 'user', content: promptText });
          } else if (Array.isArray(promptText)) {
            messages.push(...promptText);
          }
        }
        
        const requestParams = {
          model,
          messages,
          temperature: config.temperature ?? 0.7,
          max_tokens: config.maxTokens || config.max_tokens || 2000,
        };
        
        if (config.response_json_schema) {
          requestParams.response_format = { type: 'json_object' };
          if (wantsJson && systemPrompt && !messages.some(m => m.role === 'system' && m.content.includes('JSON'))) {
            const sysIdx = messages.findIndex(m => m.role === 'system');
            if (sysIdx >= 0) {
              messages[sysIdx].content += '\n\nRespond with valid JSON only.';
            }
          }
        }
        
        const response = await openai.chat.completions.create(requestParams);
        
        const content = response.choices[0]?.message?.content || '';
        
        if (wantsJson) {
          try {
            const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/) || 
                             [content.match(/\{[\s\S]*\}/)?.[0] || content.match(/\[[\s\S]*\]/)?.[0]];
            if (jsonMatch && jsonMatch[0]) {
              const jsonStr = jsonMatch[1] || jsonMatch[0];
              const parsed = JSON.parse(jsonStr.trim());
              return parsed;
            }
            return JSON.parse(content.trim());
          } catch (e) {
            console.warn('Failed to parse JSON response, returning raw:', e);
            return content;
          }
        }
        
        return content;
      } catch (error) {
        console.error('InvokeLLM error:', error);
        return { 
          success: false, 
          message: error.message || 'Failed to invoke LLM',
          response: null 
        };
      }
    },
    
    SendEmail: async (options) => {
      console.log('[Integration] SendEmail called - not implemented');
      return { success: false, message: 'Email integration not configured' };
    },
    
    UploadFile: async (file, options) => {
      console.log('[Integration] UploadFile called - not implemented');
      return { success: false, message: 'File upload not configured' };
    },
    
    GenerateImage: async (prompt, options) => {
      console.log('[Integration] GenerateImage called - not implemented');
      return { success: false, message: 'Image generation not configured' };
    },
    
    ExtractDataFromUploadedFile: async (fileUrl, options) => {
      console.log('[Integration] ExtractDataFromUploadedFile called - not implemented');
      return { success: false, message: 'File extraction not configured' };
    },
    
    CreateFileSignedUrl: async (fileName, options) => {
      console.log('[Integration] CreateFileSignedUrl called - not implemented');
      return { success: false, message: 'Signed URL creation not configured' };
    },
    
    UploadPrivateFile: async (file, options) => {
      console.log('[Integration] UploadPrivateFile called - not implemented');
      return { success: false, message: 'Private file upload not configured' };
    },
    
    GetJobRecommendations: async (userProfile, availableJobs) => {
      try {
        const prompt = `Based on this developer's profile and available jobs, recommend the top 5 most suitable positions.

Developer Profile:
- Skills: ${userProfile.skills?.join(', ') || 'Not specified'}
- Roles: ${userProfile.developer_roles?.join(', ') || 'Not specified'}
- Experience: ${userProfile.experience_level || 'Not specified'}
- Work Status: ${userProfile.work_status || 'available'}
- Hourly Rate: ${userProfile.hourly_rate || 'Not specified'}

Available Jobs:
${availableJobs.slice(0, 20).map((job, i) => `${i + 1}. ${job.title} - ${job.category || 'General'} - ${job.budget_type}: ${job.budget_min || 0}-${job.budget_max || 'N/A'} - Skills: ${job.required_skills?.join(', ') || 'None specified'}`).join('\n')}

Return a JSON array of job indices (1-based) with match scores and reasons:
[{"index": 1, "score": 85, "reason": "Strong skill match in scripting"}]`;

        const result = await integrations.Core.InvokeLLM(prompt, {
          systemPrompt: 'You are a job matching AI for Roblox developers. Return only valid JSON.',
          json: true,
          temperature: 0.3
        });
        
        if (result && result.success === false) {
          console.warn('GetJobRecommendations: AI call failed', result.message);
          return [];
        }
        
        const recommendations = Array.isArray(result) ? result : [];
        return recommendations.map(rec => ({
          job: availableJobs[rec.index - 1],
          score: rec.score,
          reason: rec.reason
        })).filter(r => r.job);
      } catch (error) {
        console.error('GetJobRecommendations error:', error);
        return [];
      }
    },
    
    GenerateProfileSuggestions: async (userProfile) => {
      try {
        const prompt = `Analyze this Roblox developer's profile and provide improvement suggestions:

Profile:
- Name: ${userProfile.full_name || 'Not set'}
- Bio: ${userProfile.bio || 'Not set'}
- Skills: ${userProfile.skills?.join(', ') || 'None listed'}
- Roles: ${userProfile.developer_roles?.join(', ') || 'None listed'}
- Experience: ${userProfile.experience_level || 'Not specified'}
- Hourly Rate: ${userProfile.hourly_rate || 'Not set'}
- Portfolio: ${userProfile.portfolio_url || 'Not linked'}
- Roblox Verified: ${userProfile.roblox_verified ? 'Yes' : 'No'}

Provide 3-5 specific, actionable suggestions to improve this profile for attracting job opportunities on a Roblox developer job board.

Return as JSON: [{"category": "bio", "suggestion": "...", "priority": "high"}]`;

        const result = await integrations.Core.InvokeLLM(prompt, {
          systemPrompt: 'You are a career coach specializing in Roblox development careers. Return only valid JSON.',
          json: true,
          temperature: 0.5
        });
        
        if (result && result.success === false) {
          console.warn('GenerateProfileSuggestions: AI call failed', result.message);
          return [];
        }
        
        return Array.isArray(result) ? result : [];
      } catch (error) {
        console.error('GenerateProfileSuggestions error:', error);
        return [];
      }
    }
  }
};

export const base44 = {
  entities,
  functions,
  auth: authModule,
  integrations,
};

export { supabase };
